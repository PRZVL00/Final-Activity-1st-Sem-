function check_input(event) {
    var fname = document.getElementById('fname').value;
    var lname = document.getElementById('lname').value;
    var cellnum = document.getElementById('cellnum').value;
    var email = document.getElementById('email').value;
    var numguest = document.getElementById('numguest').value;
    var room = document.getElementById('rooms').value;
    var cidate = document.getElementById('cidate').value;
    var codate = document.getElementById('codate').value;

    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    var today = mm + '/' + dd + '/' + yyyy;

    var date1 = new Date(cidate);
    var date2 = new Date(codate);
    var date_today = new Date(today);
    var Difference_In_Time_Today = date1.getTime() - date_today.getTime();
    var Difference_In_Days_Today = Difference_In_Time_Today / (1000 * 3600 * 24);
    var Difference_In_Time = date2.getTime() - date1.getTime();
    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);


    if (fname.length == 0 || lname.length == 0 || cellnum.length == 0 || email.length == 0 ||
        numguest == 0 || numguest > 5) {
        alert('Incomplete/Invalid Form. Please Fill Up the Form');
        event.preventDefault()
    } else if (cellnum.length < 11) {
        alert('Invalid Phone Number');
        event.preventDefault()
    } else if (cellnum.charAt(0) != 0 || cellnum.charAt(1) != 9) {
        alert('Invalid Phone Number')
    } else if (email.substring(confirmationofemail, endofemail) != '@gmail.com') {
        alert('Invalid Email Format')
        event.preventDefault()
    }else if (Difference_In_Days_Today <= 0) {
        alert('Invalid Check In Date')
        event.preventDefault()
    } else if (Difference_In_Days < 1) {
        alert('Invalid Check Out Date')
        event.preventDefault()
    } else {
        document.getElementById('days').value = Difference_In_Days
        if (confirm("Are you sure you want to proceed?") == true) {
            document.getElementById('registration_form').submit()
            location.href = 'SUNBEAM_Billing.php'
        } else {
            pass;
        }
    }
}

function act_check(){
    var act1 = document.getElementById("act1");
    var act2 = document.getElementById("act6");
    var act3 = document.getElementById("act3");
    var act4 = document.getElementById("act4"); 
    var act5 = document.getElementById("act5");

    if(act1.checked){
        document.getElementById('activities').value = 'I'
        act_price = act_price + 500
    }else{
        document.getElementById('activities').value = 'O'
    }

    if(act2.checked){
        document.getElementById('activities').value = document.getElementById('activities').value + 'I'
        act_price = act_price + 500
    }else{
        document.getElementById('activities').value = document.getElementById('activities').value + 'O'
    }

    if(act3.checked){
        document.getElementById('activities').value = document.getElementById('activities').value + 'I'
        act_price = act_price + 500
    }else{
        document.getElementById('activities').value = document.getElementById('activities').value + 'O'
    }

    if(act4.checked){
        document.getElementById('activities').value = document.getElementById('activities').value + 'I'
        act_price = act_price + 500
    }else{
        document.getElementById('activities').value = document.getElementById('activities').value + 'O'
    }

    if(act5.checked){
        document.getElementById('activities').value = document.getElementById('activities').value + 'I'
        act_price = act_price + 500
    }else{
        document.getElementById('activities').value = document.getElementById('activities').value + 'O'
    }
}

// Cancel button Fucntion
function cancel_input() {
    if (confirm("Are you sure you want to Cancel?") == true) {
        location.href = 'SUNBEAM_Hompage.php'
    }
}

//functions for buttons for choosing rooms
function room1() {
    document.getElementById("rooms").selectedIndex = "0"
}

function room2() {
    document.getElementById("rooms").selectedIndex = "1"
}

function room3() {
    document.getElementById("rooms").selectedIndex = "2"
}

function room4() {
    document.getElementById("rooms").selectedIndex = "3"
}

function room5() {
    document.getElementById("rooms").selectedIndex = "4"
}

function room6() {
    document.getElementById("rooms").selectedIndex = "5"
}

function room7() {
    document.getElementById("rooms").selectedIndex = "6"
}

function room8() {
    document.getElementById("rooms").selectedIndex = "7"
}

function room9() {
    document.getElementById("rooms").selectedIndex = "8"
}

function room10() {
    document.getElementById("rooms").selectedIndex = "9"
}

function keylimit_fname(){
    if (document.getElementById("fname").value.length == 20){
        alert('Maximum Limit of Characters have been reached.')
    } else{
        pass
    }
} 