
<?php

include 'connect.php';

if(isset($_POST['submit'])){
    $fname= $_POST['fname'];
    $lname= $_POST['lname'];
    $cnum= $_POST['cellnum'];
    $email= $_POST['email'];
    $rooms= $_POST['room'];
    $guest= $_POST['numguest'];
    $cidate= $_POST['cid'];
    $codate= $_POST['cod'];
    $acts= $_POST['activities'];


    $sql = "insert into `customers` (c_fname, c_lname, c_num, c_email,	c_room, c_numguest,	c_cidate, c_codate, c_acts) 
            values('$fname','$lname', '$cnum', '$email', '$rooms', '$guest', '$cidate', '$codate', '$acts')";
    $result = mysqli_query($con, $sql);

    if(!$result){
        die(mysqli_error($con));
    }
}

?>

<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="billing_style.css">
    <script src="billing_script.js"></script>
    <title>SUNBEAM RESORT</title>

    

</head>

<header>
    <img class="logo" src="left.png" alt="logo">
    <nav>
        <ul class="nav">
            <h1 class="text">SUNBEAM RESORT</h1>
        </ul>
    </nav>
    <img class="logo" src="right.png" alt="logo">

</header>

<body id="bg" style = "background-image:url('bg2.jpg');">


    <section>
        <div class="leftbox">
            <h4> Customer Name</h4>
            <div class="row">
                <div class="innerleftleft">
                    <h4> Check In Date: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> XX/XX/XXXX XX:XX XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Check Out Date: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> XX/XX/XXXX XX:XX XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Room Name: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> XXXXXXXXXX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Number of Guest: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Availed Activity: </h4>
                </div>
                <div class="innerrightleft">
                    <h4 id="availedact"> Activity 1 </h4>
                    <h4 id="availedact"> Activity 2 </h4>
                    <h4 id="availedact"> Activity 3 </h4>
                    <h4 id="availedact"> Activity 4 </h4>
                    <h4 id="availedact"> Activity 5 </h4>
                </div>
            </div>
        </div>

        <div class="rightbox">
            <h4> Price Breakdown</h4>
            <div class="row">
                <div class="innerleftleft">
                    <h4> Stay In Price: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> PHP XXXXX.XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Activities: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> PHP XXXXX.XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Amenities: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> PHP XXXXX.XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Environmental Fee: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> PHP XXXXX.XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Reservation Fee: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> PHP XXXXX.XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <h4> Total: </h4>
                </div>
                <div class="innerrightleft">
                    <h4> PHP XXXXX.XX </h4>
                </div>
            </div>

            <div class="row">
                <div class="innerleftleft">
                    <a href="SUNBEAM_Reservation.php"> <button class=" button button3" id="btn1">Cancel</button></a>
                </div>
                <div class="innerrightleft">
                    <button class=" button button1" id="btn2"><a href = "SUNBEAM_Confirmation.php">Proceed</a></button>
                </div>
            </div>
        </div>

    </section>

</body>

</html>