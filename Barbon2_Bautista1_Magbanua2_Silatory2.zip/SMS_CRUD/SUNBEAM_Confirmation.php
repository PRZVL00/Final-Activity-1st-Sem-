

<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="confirmation_style.css">
    <script src="confirmation_script.js"></script>


    <title>SUNBEAM RESORT</title>

</head>

<!-- <header>
<img class="logo" src="left.png" alt="logo">
<nav>
    <ul class="nav">
        <h1 class="text">SUNBEAM RESORT&nbsp;&nbsp;&nbsp;</h1>
    </ul>
</nav>
<img class="logo" src="right.png" alt="logo">

</header> -->

<body id="bg" style = "background-image:url(bg2.jpg)">

    <section>
        <div class="box">
            <h2> Reservation Successful!</h2>
            <p>Here is your confirmation number. Please present this to the</p>
            <p> front desk while checking in.</p>
            <p>&nbsp;</p>
            <i class="fa fa-asterisk" style="font-size:40px"></i>
            <i class="fa fa-asterisk" style="font-size:40px"></i>
            <i class="fa fa-asterisk" style="font-size:40px"></i>
            <i class="fa fa-asterisk" style="font-size:40px"></i>
            <i class="fa fa-asterisk" style="font-size:40px"></i>
            <i class="fa fa-asterisk" style="font-size:40px"></i>
            <p>&nbsp;</p>
            <button class="button button1"><a href = 'SUNBEAM_Hompage.php'>Done</a></button>

        </div>

    </section>

</body>

</html>