<?php

include 'connect.php';

if(isset($_POST['submit'])){
    $commented= $_POST['comment'];

    $sql = "insert into `feedback` (f_response) values('$commented')";
    $result = mysqli_query($con, $sql);

    if(!$result){
        die(mysqli_error($con));
    }
}

?>

<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="home_style.css">
    <script src="home_script.js"></script>    


    <title>SUNBEAM RESORT</title>


</head>


<!-------------- NAV BAR ------------------>

<header>

    <img class="logo" src="left.png" alt="logo">
    <nav class="navbar navbar-expand-lg navbar-light ng-light">

        <a class="cta" onclick="reservation()"><button>BOOK NOW</button></a>

    </nav>

</header>

<body>



    <!----------------- CAROUSEL ----------------->

    <section class="myslide">
        <div id="myCarousel" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <ol class="carousel-indicators">
                <li data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"></li>
                <li data-bs-target="#myCarousel" data-bs-slide-to="1"></li>
                <li data-bs-target="#myCarousel" data-bs-slide-to="2"></li>
                <li data-bs-target="#myCarousel" data-bs-slide-to="3"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active" data-bs-interval="10000" style="background-image:url(./slide1.jpg);">
                    <div class="container">
                        <h1>WELCOME TO SUNBEAM RESORT</h1>
                        <p style="font-size: 20px;">The resort is located in one of the Philippines’ most reknowned jump off sites <br> for diving. Blessed with abundant underwater marine life, plenty of corals <br> and an amazing diversity of fishes.

                    </div>
                </div>
                <div class="carousel-item" style="background-image:url(./slide2.jpg);">
                    <div class="container1">
                        <p style="font-size: 20px; color: #ffffff;">
                            Our resort offers a variety of water sports activities, <br> including scuba diving, jet skiing, and wind surfing.
                        </p>
                    </div>
                </div>
                <div class="carousel-item" data-bs-interval="10000" style="background-image:url(./slide3.jpg); ">
                    <div class="container2">
                        <p style="font-size: 20px; color: #ffffff; font-weight: 400;">
                            If you’ve always been fascinated by underwater scenery, now’s the time to <br> learn to dive. Begin with the Sun Beam PADI Open Water Diver Course.<br> In the PADI Open Water Diver course, your PADI Instructor takes you <br>                            through the basics of learning how to scuba dive.
                        </p>
                    </div>
                </div>
                <div class="carousel-item" style="background-image:url(./slide4.jpg);">
                    <div class="container3">
                        <p style="font-size: 20px; color: #ffffff;">You get the best of both worlds when you stay at Sunbeam Resort. <br> The sea at your doorstep, and the amenities of modern living.</p>
                    </div>
                </div>
            </div>
            <a href="#myCarousel" class="carousel-control-prev" role="button" data-bs-slide="prev">
                <span class="sr-only"></span>
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a href="#myCarousel" class="carousel-control-next" role="button" data-bs-slide="next">
                <span class="sr-only"></span>
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    </section>


    <!---------------- FOOTER ----------------->

    <footer class="footer">
        <div class="container-footer">

            <div class="row">
                <div class="footer-col">
                    <h4>HOW WAS YOUR VISIT?</h4>
                    <p>Your feedback will help us to improve <br> our services.</p>
                    <form method='POST' id='feedback_form'>
                    <textarea id="comment" name="comment" placeholder="Type here...(Minumum of 20 Characters)"  minlength="20" ></textarea><br>
                    <button id="submit" class="submit" name="submit">SUBMIT</button>
                    </form>
                </div>

                <div class="footer-col">
                    <h4>SUNBEAM RESORT</h4>
                    <p>Sitio Looc, Barangay Bagalangit, Anilao, <br> Mabini 4202, Batangas, Philippines</p>
                    <a><i class="fas fa-phone" style="font-size:15px">&nbsp;&nbsp;(043) 934 3140</i></a>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                </div>
            </div>
        </div>

        <div class="footer-bottom"> &copy; All rights reserved &nbsp; | &nbsp;
            <a class="login" href="SUNBEAM_LogIn.php" style="width:auto;">LOGIN</a>
        </div>
    </footer>
    </div>


</body>

</html>

</html>