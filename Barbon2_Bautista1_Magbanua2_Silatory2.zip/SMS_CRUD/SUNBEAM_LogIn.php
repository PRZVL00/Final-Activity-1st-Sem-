<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="log_in_script.js"></script>
    <link rel="stylesheet" href="log_in_style.css">
    <title>Log In</title>

</head>

<body id="bg" style = "background-image:url(bg.jpg);">
    <div class="card">
        <div class="card3">
            <h1 style="text-align: center; color: white;">Log In</h1>
        </div>
            <div class="card2">
                <div class="row">
                    <div class="inside_leftcolumn2">
                <form action = 'SUNBEAM_Managerial.php'>
                        <label for="fname" id="usrnm">Username:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="text" id="username" name="username" value = "" onkeypress="letter(event)" required>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                    <div class="inside_leftcolumn2">
                        <label for="lname" id="pswrd">Password:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="password" id="password" name="password" value = "" onkeypress="letter(event)"required>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                        <button class=" button button3" onclick="cancel()"><a href='SUNBEAM_Hompage.php'>Cancel</a></button>
                        <button class=" button button1" onclick="validate()"><a href='SUNBEAM_Managerial.php'id='go'>Proceed</a></button>
                        <button class=" button button1" ><a href='SUNBEAM_SignUP.php'id='gos'>Sign In</a></button>
                </div>
    
            </div>
        </form>
    </div>
</body>

</html>