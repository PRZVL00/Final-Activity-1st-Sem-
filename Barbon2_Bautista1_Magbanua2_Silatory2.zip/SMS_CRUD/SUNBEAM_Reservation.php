<?php

include 'connect.php';

if(isset($_POST['submit'])){
    $fname= $_POST['fname'];
    $lname= $_POST['lname'];
    $cnum= $_POST['cellnum'];
    $email= $_POST['email'];
    $rooms= $_POST['room'];
    $guest= $_POST['numguest'];
    $cidate= $_POST['cid'];
    $codate= $_POST['cod'];
    $acts= $_POST['activities'];
    $days= $_POST['days'];
    $total = $_POST['total'];
    $status = $_POST['status'];


    $sql = "INSERT into `customers` (c_fname, c_lname, c_num, c_email,	c_room, c_numguest,	c_cidate, c_codate, c_acts, c_days, c_total, c_status)
            VALUES('$fname','$lname', '$cnum', '$email', '$rooms', '$guest', '$cidate', '$codate', '$acts', '$days', '$total', '$status')";
    $result = mysqli_query($con, $sql);

    if(!$result){
        die(mysqli_error($con));
    }

}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="reservation_style.css">
    <title>Reservation</title>
</head>


<header>
    <img class="logo" src="left.png" alt="logo">
    <nav>
        <ul class="nav">
            <h1 class="text">SUNBEAM RESORT</h1>
        </ul>
    </nav>
    <img class="logo" src="right.png" alt="logo">

</header>



<body id="bg" style = "background-image:url(bg2.jpg);">
    <script src="Reservaion_module_script.js"></script>
    <div class="row">
        <div class="leftcolumn">

            <?php

                include 'connect.php';

                $sql3 = "Select * from `rooms` where `r_status` =  'Vacant' ORDER BY `rooms`.`r_price` ASC";
                $result3 = mysqli_query($con, $sql3);

                if($result3){
                    while($option = mysqli_fetch_assoc($result3)){
                    $num = $option['r_num'];
                    $name = $option['r_name'];
                    $price = $option['r_price'];
                    $pic = $option['r_pic'];
                    $detail = $option['r_detail'];
                    $info = $option['r_info'];

                    echo '<div class="card">
                    <div class="card2">
                        <h2 class="pdetails">Room No. '.$num.' - The '.$name.'</h2>
                        <h3 class="pdetails">₱ '.$price.'.00</h3>
                        <div class="inside_leftcolumn">
                            <img class="fakeimage" src="'.$pic.'" alt="logo">
                        </div>
                        <div class="inside_rightcolumn">
                            <p>'.$detail.'</p>
                            <button type="button" class=" button button2 btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal'.$num.'">Room Info</button>
                        </div>
                    </div>
                    <button class="button button1" onclick=room'.$num.'()>Select</button>
                </div>
    
                <!-- Room 1 Modal -->
                <div class="modal" id="myModal'.$num.'">
                    <div class="modal-dialog">
                      <div class="modal-content">
                  
                        <!-- Modal Header -->
                        <div class="modal-header">
                          <h4 class="modal-title">The '.$name.'</h4>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                  
                        <!-- Modal body -->
                        <div class="modal-body">
                            <p>
                                '.$info.'
                            </p>					  
                        </div>
                  
                        <!-- Modal footer -->
                        <div class="modal-footer">
                          <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                        </div>
                  
                        </div>
                    </div>
                </div>';}}

                if(!$result3){
                    die(mysqli_error($con));}
                ?>

        </div>

        <!-- ----------------------------------------------------------------------------------------------------------------------------- -->

        <div class="rightcolumn">
            <div class="card">
                <div class="card3">
                    <h2 style="text-align: center;">Make your Reservation</h2>
                </div>
                <form id="reservation_form" method='POST' action = 'SUNBEAM_Billing.php'>
                <div class="card2">
                    <div class="row">
                        <div class="inside_leftcolumn2">
                            <label for="fname" id="label1">First name:</label>
                            <br>
                        </div>
                        <div class="inside_rightcolumn2">
                            <input type="text" id="fname" name="fname" class="input" maxlength="20" minlength="1" placeholder="First Name" required>
                            <br>
                        </div>
                    </div>

                    <div class="row">
                        <div class="inside_leftcolumn2">
                            <label for="lname" id="label1">Last name:</label>
                            <br>
                        </div>
                        <div class="inside_rightcolumn2">
                            <input type="text" id="lname" name="lname" class="input" maxlength="20" minlength="1" placeholder="Last Name" required>
                            <br>
                        </div>
                    </div>

                    <div class="row">
                        <div class="inside_leftcolumn2">
                            <label for="cellnum" id="label1">Cell number:</label>
                            <br>
                        </div>
                        <div class="inside_rightcolumn2">
                            <input type="tel" id="cellnum" name="cellnum" class="input" pattern="[0-9]{11}" placeholder="09XXXXXXXXX" required>
                            <br>
                        </div>
                    </div>

                    <div class="row">
                        <div class="inside_leftcolumn2">
                            <label for="email" id="label1">Email:</label>
                            <br>
                        </div>
                        <div class="inside_rightcolumn2">
                            <input type="email" id="email" name="email" class="input" pattern="[a-zA-Z0-9._%+-]+@gmail.com" placeholder="XXXXXX.gmail.com" required>
                            <br>
                        </div>
                    </div>

                    <div class="row">
                        <div class="inside_leftcolumn2">
                            <label for="rooms" id="label1">Rooms:</label>
                            <br>
                        </div>
                        <div class="inside_rightcolumn2">
                            <select name="room" id="rooms" class="input">
                            <?php

                                include 'connect.php';

                                $sql2 = "Select `r_name` from `rooms` where `r_status` =  'Vacant' ORDER BY `rooms`.`r_price` ASC";
                                $result2 = mysqli_query($con, $sql2);

                                if($result2){
                                    while($option = mysqli_fetch_assoc($result2)){
                                        $available = $option['r_name'];
                                        echo '<option value="'.$available.'" id="'.$available.'">'.$available.'</option>';}}

                                if(!$result2){
                                    die(mysqli_error($con));}
                                ?>
								</select>
                            <br>
                        </div>
                    </div>

                    <div class="row">
                        <div class="inside_leftcolumn2">
                            <label for="numguest" id="label1">Guest:</label>
                            <br>
                        </div>
                        <div class="inside_rightcolumn2">
                            <input type="number" id="numguest" name="numguest" class="input" min="1" max="10" required>
                            <br>
                        </div>
                    </div>

                    <div class="row">
                        <div class="inside_leftcolumn2">
                            <label for="cid" id="label1">Check In Date:</label>
                            <br>
                        </div>
                        <div class="inside_rightcolumn2">
                            <input type="date" id="cidate" name="cid" class="input" required>
                            <br>
                        </div>
                    </div>

                    <div class="row">
                        <div class="inside_leftcolumn2">
                            <label for="cod" id="label1">Check Out Date:</label>
                            <br>
                        </div>
                        <div class="inside_rightcolumn2">
                            <input type="date" id="codate" name="cod" class="input" required>
                            <br>
                            <br>
                        </div>
                        <input type="hidden" id="days" name="days" class="input">
                    </div>

                    <h3 id="activity">Activities</h3>

                    <div class="row">
                        <div class="inside_leftcolumn3">
                            <input type="checkbox" id="act1" name="act1" value="Activity 1">
                            <label for="act1" id="act2"> Activity 1</label><br>
                            <input type="checkbox" id="act6" name="act2" value="Activity 2">
                            <label for="act2" id="act2">Activity 2</label><br>
                            <input type="checkbox" id="act3" name="act3" value="Activity 3">
                            <label for="act3" id="act2"> Activity 3</label><br>
                        </div>
                        <div class="inside_rightcolumn3">
                            <input type="checkbox" id="act4" name="act4" value="Activity 4">
                            <label for="act4" id="act2"> Activity 4</label><br>
                            <input type="checkbox" id="act5" name="act5" value="Activity 5">
                            <label for="act5" id="act2"> Activity 5</label><br>
                            <input type="hidden" id="activities" name="activities" class="input">
                        </div>
                    </div>
                    <br>
                    <input type="hidden" id="total" name="total" class="input">
                    <input type="hidden" id="status" name="status" class="input" value='Reserved'>
                    <br>
                    <div class="row">
                        <div class="inside_leftcolumn3">
                            <input class=" button button3" type="reset" id="reset" value="Cancel" onclick="cancel_input()">
                        </div>
                        <div class="inside_rightcolumn3">
                            <input class="button button1" type="submit" id="submit" value="Proceed" name='submit' onclick="check_input(event)">
                        </div>
                    </div>

                </div>

                </form>
            </div>
        </div>
    </div>
    <div class="footer">
        <p>&copy; All Rights Reserved.</p>
    </div>

</body>

</html>