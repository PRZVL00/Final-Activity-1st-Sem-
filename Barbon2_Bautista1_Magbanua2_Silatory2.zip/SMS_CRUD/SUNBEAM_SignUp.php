<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="SIGN_UP.js"></script>
    <link rel="stylesheet" href="signup_style.css">
    <title>Sign Up</title>

</head>

<body>
    <div class="card">
        <div class="card3">
            <h1 style="text-align: center; color: white;">Sign Up</h1>
        </div>
            <div class="card2">
                <div class="row">
                    <div class="inside_leftcolumn2">
                        <label for="fname" id="fname">First name:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="text" id="i_fname" name="fname" value = "" onkeypress="letter(event)" required>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                    <div class="inside_leftcolumn2">
                        <label for="lname" id="lname">Last name:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="text" id="i_lname" name="lname" value = "" onkeypress="letter(event)"required>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                    <div class="inside_leftcolumn2">
                        <label for="cellnum" id="cnum">Id number:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="tel" id="i_cnum" name="cellnum" onkeypress="number(event)" required>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                    <div class="inside_leftcolumn2">
                        <label for="email" id="email">Email:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="email" id="i_email" name="email"required>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                    <div class="inside_leftcolumn2">
                        <label for="rooms" id="pword">Pasword:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="password" id="i_pword" name="password" value = "" required>
                        <span id = "message1" style="color:red"> </span>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                    <div class="inside_leftcolumn2">
                        <label for="numguest" id="pword2">Confirm Password:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="password" id="i_pword2" name="password2" value = "" required>
                        <span id = "message2" style="color:red"> </span>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                    <div class="inside_leftcolumn2">
                        <label for="cid" id="code">Code:</label>
                        <br>
                    </div>
                    <div class="inside_rightcolumn2">
                        <input type="text" id="i_code" name="numguest"  onkeypress="number(event)" required>
                        <br>
                    </div>
                </div>
    
                <div class="row">
                    <div class="inside_leftcolumn3">
                        <button class=" button button3"><a href = 'SUNBEAM_Hompage.php'>Cancel</a></button>
                    </div>
                    <div class="inside_rightcolumn3">
                        <button class=" button button1" onclick="validateForm()">Proceed</button>
                    </div>
                </div>
    
            </div>
        </form>
    </div>
</body>

</html>