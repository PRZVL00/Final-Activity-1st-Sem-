function cancel(){
    location.href = "http://localhost/SMS_CRUD/SUNBEAM_Reservation.php"
}