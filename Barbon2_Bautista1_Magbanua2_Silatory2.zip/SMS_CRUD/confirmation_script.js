function proceed(){
    window.location.assign('home');
}