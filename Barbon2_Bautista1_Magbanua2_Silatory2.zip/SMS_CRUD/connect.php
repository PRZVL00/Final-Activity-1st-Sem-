<?php

$con = new mysqli('localhost', 'SMS_Admin', 'SMS_admin', 'sunbeam_db');

if(!$con){
    die(mysqli_error($con));
} 

?>