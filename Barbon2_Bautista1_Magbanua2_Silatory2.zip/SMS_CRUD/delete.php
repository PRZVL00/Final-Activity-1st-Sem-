<?php

include 'connect.php';
if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    $sql = "DELETE FROM `customers` WHERE c_id = $id";
    $result = mysqli_query($con, $sql);

    if($result){
        header('location:SUNBEAM_Managerial.php');
    } 

}


?>  