function validate () {
    var username = document.getElementById("username").value;
    var password = document.getElementById ("password").value;
    
    if (username.length == 0 || password.length == 0) {
        alert("Please Fill Up the Form")
    
    }else if (username != 'admin' || password != 'admin') {
        alert("Invalid Username/Password")
    
    }else {
       alert("Successfuly Logged In")
       nxtpage()
    }
}

function nxtpage(){
    window.location.assign('managerial/')
}


function cancel() {
    document.getElementById('username').value = "";
    document.getElementById('password').value = "";
}

function reservation() {
    window.location.assign('http://localhost/SMS_CRUD/SUNBEAM_Reservation.php')
}

function log_in (){
    window.location.replace('SUNBEAM_Reservation.php')
}