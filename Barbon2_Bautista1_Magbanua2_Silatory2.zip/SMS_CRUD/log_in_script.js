function validate () {
    var username = document.getElementById("username").value;
    var password = document.getElementById ("password").value;
    
    if (username.length == 0 || password.length == 0) {
        alert("Please Fill Up the Form")
    
    }else if (username != 'admin' || password != 'admin') {
        alert("Invalid Username/Password")
    
    }else {
       alert("Successfuly Logged In")
       document.getElementById('go').click
    }
}

function cancel() {
    document.getElementById('username').value = "";
    document.getElementById('password').value = "";
    window.location.assign('SUNBEAM_Hompage.php')
}