<?php

include 'connect.php';
if(isset($_GET['updateid'])){
    $id=$_GET['updateid'];

    $sql = "UPDATE `customers` SET `c_status` = 'Check In' WHERE c_id=$id";
    $result = mysqli_query($con, $sql);

    if($result){
        header('location:SUNBEAM_Managerial.php');
    } 

}

?>  